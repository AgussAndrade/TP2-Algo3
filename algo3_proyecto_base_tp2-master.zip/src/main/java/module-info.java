module edu.fiuba.algo3 {
    requires javafx.controls;
    exports edu.fiuba.algo3;
}